"""



"""


class LayerPackagingException(Exception):
    """
    Raised when layer packaging fails
    """